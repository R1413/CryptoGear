/*
 * Vivo Applications
 *
 * Javascript for the training page.
*/

(function() {
    "use strict";

    /* Set up - such as onclick events, etc. */
    window.onload = function() {
        setActivePage();
    };

}) ();



