/*
 * Vivo Applications
 *
 * Javascript for the profile page.
*/

(function() {
    "use strict";

    /* Set up - such as onclick events, etc. */
    window.onload = function() {
        setActivePage();
    };

}) ();